const options = [ // массив с опциями голосования
    { value: -1, label: "Against all" },
    { value: "YEAH BOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOIIIIIIIIIIIIIIIIIIIIII", label: "Паша Техник" },
    { value: 1, label: "Donald Trump" }
]

const registration = [ // массив с параметрами импутов в регистрации
    { name: "Name", placeholder: "Type your name here", id: "name" },
    { name: "Surname", placeholder: "Type your surname here", id: "surname" },
    { name: "Number", placeholder: "+373 Type your number here", id: "number" }
]

const buildForm = (options, registration) => { // передаём массивы options и registration в функцию в виде аргументов
    var voteForm = document.getElementById('vote')

    registration.forEach(function (element, i) {
        var regForm = document.createElement('input')
        regForm.id = element.id
        regForm.type = "text"
        regForm.placeholder = element.placeholder
        regForm.name = element.name
        var br = document.createElement('br') // повторяющийся код
        voteForm.appendChild(regForm)
        voteForm.appendChild(br) // повторяющийся код        
    })

    options.forEach(function (element, i) {
        var option = document.createElement('input')
        option.type = "radio"
        option.name = "candidate"
        option.value = options[i].value // тут решил поэкспериментировать с [i]
        option.label = options[i].label // тут решил поэкспериментировать с [i]
        var text = document.createTextNode(option.label)
        var br = document.createElement('br') // повторяющийся код 
        voteForm.appendChild(option)
        voteForm.appendChild(text)
        voteForm.appendChild(br) // повторяющийся код
    })

    var button = document.createElement('button')
    button.innerHTML = "VOTE"
    button.onclick = (event) => {// функция сробатывающая при нажатии на кнопу VOTE

        event.preventDefault()
        var inputNameValue = document.getElementById('name').value        //
        var inputSurnameValue = document.getElementById('surname').value  // содержимое input
        var inputNumberValue = document.getElementById('number').value    //
        var expNamePattern = /[a-zA-Z]{6,}$/
        var expNumberPattern = /^\+(373)([0-9]{8})$/
        try {
            var selectedCandidate = document.querySelector('#vote input:checked').value
        } catch (error) {
            alert('No candidate selected!')
        }
        // length and UTF of name and surname inputs value
        try {
            if (expNamePattern.test(inputNameValue) == false || expNamePattern.test(inputSurnameValue) == false) { // паттерн тестирует содержимое input
                throw new SyntaxError("Ошибка в имени");
            }
        } catch (error) {
            if (error.name == "SyntaxError") {
                alert("Invalid name or surname! Please, try again!");
            } else {
                throw error;
            }
        }
        // ----------------------------------------------------------
        // length of telephone number input value
        try {
            if (expNumberPattern.test(inputNumberValue) == false) {
                throw new SyntaxError("Ошибка в номере");
            }
        } catch (error) {
            if (error.name == "SyntaxError") {
                alert("Invalid number");
            } else {
                throw error;
            }
        }

        fetch('http://localhost:3000/vote', { // запрос на сервер
            method: 'POST', // метод запроса ---> ОТДАЁТ
            mode: 'cors', // no-cors, cors, *same-origin
            cache: 'no-cache', // *default, no-cache, reload, force-cache, only-if-cached
            credentials: 'same-origin', // include, *same-origin, omit
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
                // 'Content-Type': 'application/x-www-form-urlencoded',
            },
            redirect: 'follow', // manual, *follow, error
            referrer: 'no-referrer', // no-referrer, *client
            body: JSON.stringify(selectedCandidate), // тело запроса
        })
            // .then(response => response.json())
            .then(response => {
                console.log(response) // после, законсоль ответ с сервера
            })
    }
    voteForm.appendChild(button)
}
buildForm(options, registration)
