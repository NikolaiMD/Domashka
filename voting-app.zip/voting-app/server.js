const http = require('http')

http.createServer((request, response) => {
    console.log('Обработка запроса, ждём данные');
    response.setHeader('Access-Control-Allow-Origin', '*');
    response.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    response.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
    response.setHeader('Access-Control-Allow-Credentials', true);
    response.writeHead(200, { 'Content-Type': 'text/plain' });
    response.end('WORKING SERVER');   
    request.on('data', chunk => {
        console.log('Данные получены', chunk.toString()); // пришедший запрос
    });
    request.on('end', () => {
        console.log('Это всё');
    })
}).listen(3000)